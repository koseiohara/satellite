# -*- coding: utf-8 -*-
"""
Created on Wed May 20 20:38:50 2020

@author: toki6
"""

import numpy as np
import matplotlib.pyplot as plt

fp=open('N88110903_H_lon.ex','rb')
lon=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()
lon=lon*0.01

fp=open('N88110903_H_lat.ex','rb')
lat=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()
lat=lat*0.01

fp=open('N88110903_H_ch2.ex','rb')
val=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()

z=np.zeros([32,32])
gla=np.zeros([32])
glo=np.zeros([32])

for k in range(32):
    gla[k]=38.00-(512-k*32)*0.01
    glo[k]=141.0+(k*32-512)*0.01

for i in range(32):
    for j in range(32):
        print(i,j)
        d1=(lat-gla[i])*(lat-gla[i])+(lon-glo[j])*(lon-glo[j])
        d2=np.unravel_index(np.argmin(d1),d1.shape)
        z[31-i,j]=val[d2[0],d2[1]]

plt.imshow(z,cmap="gray",vmin=20,vmax=400)
plt.colorbar()
plt.xlabel('x')
plt.ylabel('y')
plt.savefig('f03b1.png')
plt.show()