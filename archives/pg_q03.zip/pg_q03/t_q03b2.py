# -*- coding: utf-8 -*-
"""
Created on Tue May  5 23:01:43 2020

@author: toki6
"""
import numba
import numpy as np
import matplotlib.pyplot as plt

@numba.jit('f8[:,:](f8[:,:],f8[:,:],f8[:],f8[:],i2[:,:])',nopython=True)
def plfnd(lat,lon,gla,glo,val):
    z=np.empty((128,128),dtype=np.float64) 
    for i2 in range(128):
        print(i2)
        for j2 in range(128):
            ds_mx=9999.9
            for i in range(4483):
                for j in range(2048):
                    ds=(lat[i,j]-gla[i2])*(lat[i,j]-gla[i2])+(lon[i,j]-glo[j2])*(lon[i,j]-glo[j2])
                    if ds_mx>ds:
                        z[127-i2,j2]=val[i,j]
                        ds_mx=ds
    return z

fp=open('N88110903_H_lon.ex','rb')
lon=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()
lon=lon*0.01

fp=open('N88110903_H_lat.ex','rb')
lat=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()
lat=lat*0.01

fp=open('N88110903_H_ch2.ex','rb')
val=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()

z=np.zeros([128,128])
gla=np.zeros([128])
glo=np.zeros([128])

for k in range(128):
    gla[k]=38.00-(512-k*8)*0.01
    glo[k]=141.0+(k*8-512)*0.01

z=plfnd(lat,lon,gla,glo,val)

plt.imshow(z,cmap="gray",vmin=20,vmax=400)
plt.colorbar()
plt.xlabel('x')
plt.ylabel('y')
plt.savefig('f03b2.png')
plt.show()
