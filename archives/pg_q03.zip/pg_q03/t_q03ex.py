# -*- coding: utf-8 -*-
"""
Created on Fri Jun  7 13:37:26 2024

@author: toki6
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
import cartopy.crs as ccrs

fp=open('N88110903_H_lon.ex','rb')
lon=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()
lon=lon*0.01

fp=open('N88110903_H_lat.ex','rb')
lat=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()
lat=lat*0.01

fp=open('N88110903_H_ch4.ex','rb')
ch4=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()

tbl_ch4 = np.loadtxt('./N88110903_H_cv4.txt', delimiter=',')

z1=np.zeros([4483,2048])
for i in range(4483):
    for j in range(2048):
        z1[i,j]=tbl_ch4[ch4[i,j],1]

cmap1=plt.colormaps['turbo']
cmap1.set_under('silver')
cmap1.set_over('black')

tmin=0.0; tmax=25.0;

fig = plt.figure(figsize=(10,15))

plt.rcParams["font.size"]=16

proj=ccrs.PlateCarree(central_longitude=140)
ax = fig.add_subplot(1, 1, 1, projection=proj)
im = ax.pcolormesh(lon,lat,z1,cmap=cmap1,vmin=tmin,vmax=tmax,transform=ccrs.PlateCarree())

# area=[115,170,10,65]
area=[138,158,28,48]
ax.set_extent(area,crs=ccrs.PlateCarree())

ax.coastlines()
gl= ax.gridlines(color='k',draw_labels=True,y_inline=False,x_inline=False,rotate_labels=False,linestyle='--',xlocs=plt.MultipleLocator(20), ylocs=plt.MultipleLocator(20))

divider = make_axes_locatable(ax)
cax = divider.new_vertical(size=0.5,pad=-2.0,axes_class=plt.Axes)  # 「下」にスペースを作る。
im = ax.imshow(z1,visible=False,cmap=cmap1,vmin=tmin,vmax=tmax)        # ダミーの画像表示
cbar = plt.colorbar(im,ax=cax,orientation='horizontal',extend='both',extendfrac=(0.05,0.05))
cbar.set_label("AVHRR CH4 TBB ($^{\circ}$C)",labelpad=10)

out_img='./maptest.png'    # 出力画像ファイル名
plt.savefig(out_img,bbox_inches='tight',pad_inches=1)
plt.show()
plt.close()