# -*- coding: utf-8 -*-
"""
Created on Tue May  5 21:23:45 2020

@author: toki6
"""

import numpy as np
import matplotlib.pyplot as plt

fp=open('avhrr-only-v2.19881109.bin','rb')
rsst=np.fromfile(fp,np.int16).reshape([720,1440])
fp.close()

fp=open('N88110903_H_lon.ex','rb')
lon=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()

fp=open('N88110903_H_lat.ex','rb')
lat=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()

z=np.zeros([4483,2048])
for i in range(4483):
    if i%500==1:
        print(i)
    for j in range(2048):
        la=lat[i,j]*0.01
        lo=lon[i,j]*0.01
        x=int((lo-0.125)/0.25+0.5)
        y=int((89.875-la)/0.25+0.5)
        z[i,j]=rsst[719-y,x]*0.1-5.0

# out_f="N88110903_H_RY.npy"
# print(out_f)
# np.save(out_f,z)

tmin=5.0; tmax=30.0
dy = 4483/256

z2=np.zeros([256,128])
for i in range(256):
    for j in range(128):
        v=z[int(i*dy),j*16]
        if v>tmax:
            v=tmax
        if v<tmin:
            v=tmin
        z2[i,j]=v

cmap = plt.cm.jet
norm = plt.Normalize(tmin,tmax)
rgba = cmap(norm(z2))
for i in range(256):
    for j in range(128):
        v=z[int(i*dy),j*16]
        if v>35.0:
            rgba[i,j,:3] = 0, 0, 0
        if v<-1.5:
            rgba[i,j,:3] = 1, 1, 1

fig,ax =plt.subplots()

ax.imshow(rgba)

x = list(range(0,192,64))
xn = ['0','1023','2048']

y = list(range(0,384,128))
yn = ['0','2048','4483']

ax.set_xlim(0,128)
ax.set_xticks(x[0:3])
ax.set_xticklabels(xn[0:3])

ax.set_ylim(256,0)
ax.set_yticks(y[0:3])
ax.set_yticklabels(yn[0:3])

ax.set_xlabel('Scan direction (X)')
ax.set_ylabel('Satellite moving direction (Y)')

im = ax.imshow(z2,visible=False,cmap=cmap)
cbar = fig.colorbar(im)
cbar.set_label('SST (degC)')

plt.savefig('f_q03a.png')
plt.show()
