# -*- coding: utf-8 -*-
"""
Created on Wed May  6 22:58:01 2020

@author: toki6
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
from matplotlib.colors import Normalize

def gauj(x,y,u,v):
    n=4
    d1=np.zeros([5,4]) 
    d2=np.zeros([5,4])
    for i in range(4):
        d1[0,i]=d2[0,i]=x[i]*y[i]
        d1[1,i]=d2[1,i]=x[i]
        d1[2,i]=d2[2,i]=y[i]
        d1[3,i]=d2[3,i]=1.0
        d1[4,i]=u[i]
        d2[4,i]=v[i]

    for k in range(n):
        for j in range(k+1,n+1):
            d1[j,k]=d1[j,k]/d1[k,k]
            d2[j,k]=d2[j,k]/d2[k,k]
        for i in range(n):
            if i != k:
               for j in range(k+1,n+1):
                   d1[j,i]=d1[j,i]-d1[k,i]*d1[j,k]
                   d2[j,i]=d2[j,i]-d2[k,i]*d2[j,k]
                    
    return d1[4,0:],d2[4,0:]

fp=open('N88110903_H_lon.ex','rb')
lon=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()
lon=lon*0.01

fp=open('N88110903_H_lat.ex','rb')
lat=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()
lat=lat*0.01

fp=open('N88110903_H_ch2.ex','rb')
ch2=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()

fp=open('N88110903_H_ch4.ex','rb')
ch4=np.fromfile(fp,np.int16).reshape([4483,2048])
fp.close()

tbl_ch2 = np.loadtxt('./N88110903_H_cv2.txt', delimiter=',')
tbl_ch4 = np.loadtxt('./N88110903_H_cv4.txt', delimiter=',')

lat_c=38.0; lon_c=141.0

img_x=1024; img_y=1024; gd=32
gd_x=int(img_x/gd)+2; gd_y=int(img_y/gd)+2

# print(gd_x,gd_y)

z1=np.zeros([img_y,img_x])
z2=np.zeros([img_y,img_x])

gla=np.zeros([gd_y,gd_x])
glo=np.zeros([gd_y,gd_x])
gpx=np.zeros([gd_y,gd_x])
gln=np.zeros([gd_y,gd_x])

for i in range(gd_y):
    for j in range(gd_x):
        gla[i,j]=lat_c-(img_y*0.5-i*gd)*0.01;
        glo[i,j]=lon_c+(j*gd-img_x*0.5)*0.01;
        
        ny=gla[i,j]; nx=glo[i,j]
        
        ps=0; pe=2047; ls=0; le=4482
        x=[lon[ls,ps],lon[ls,pe],lon[le,pe],lon[le,ps]]
        y=[lat[ls,ps],lat[ls,pe],lat[le,pe],lat[le,ps]]
        u=[ps+1,pe,pe,ps+1]
        v=[ls+1,ls+1,le,le]
        a,b=gauj(x,y,u,v)
        xx=a[0]*nx*ny+a[1]*nx+a[2]*ny+a[3]
        yy=b[0]*nx*ny+b[1]*nx+b[2]*ny+b[3]

        ps=int(xx)-32; pe=int(xx)+32; ls=int(yy)-32; le=int(yy)+32
        x=[lon[ls,ps],lon[ls,pe],lon[le,pe],lon[le,ps]]
        y=[lat[ls,ps],lat[ls,pe],lat[le,pe],lat[le,ps]]
        u=[ps+1,pe,pe,ps+1]
        v=[ls+1,ls+1,le,le]
        a,b=gauj(x,y,u,v)
        xx=a[0]*nx*ny+a[1]*nx+a[2]*ny+a[3]
        yy=b[0]*nx*ny+b[1]*nx+b[2]*ny+b[3]

        ps=int(xx)-10; pe=int(xx)+10; ls=int(yy)-10; le=int(yy)+10
        x=[lon[ls,ps],lon[ls,pe],lon[le,pe],lon[le,ps]]
        y=[lat[ls,ps],lat[ls,pe],lat[le,pe],lat[le,ps]]
        u=[ps+1,pe,pe,ps+1]
        v=[ls+1,ls+1,le,le]
        a,b=gauj(x,y,u,v)
        xx=a[0]*nx*ny+a[1]*nx+a[2]*ny+a[3]
        yy=b[0]*nx*ny+b[1]*nx+b[2]*ny+b[3]
        
        gpx[i,j]=int(xx); gln[i,j]=int(yy)
        
for gi in range(gd_y-1):
    for gj in range(gd_x-1):
        x=[gj*gd+1,gj*gd+1,(gj+1)*gd+1,(gj+1)*gd+1]
        y=[gi*gd+1,(gi+1)*gd+1,(gi+1)*gd+1,gi*gd+1]
        u=[gpx[gi,gj],gpx[gi+1,gj],gpx[gi+1,gj+1],gpx[gi,gj+1]]
        v=[gln[gi,gj],gln[gi+1,gj],gln[gi+1,gj+1],gln[gi,gj+1]]       

        a,b=gauj(x,y,u,v)
        
        for i1 in range(gd):
            for j1 in range(gd):
                ny=(y[0]-1)+i1
                nx=(x[0]-1)+j1
                xx=a[0]*(nx+1)*(ny+1)+a[1]*(nx+1)+a[2]*(ny+1)+a[3]
                yy=b[0]*(nx+1)*(ny+1)+b[1]*(nx+1)+b[2]*(ny+1)+b[3]               
                j=int(xx)
                i=int(yy);
                if 0<=i and i<4483 and 0<=j and j<2048:
                    if int(ny)<img_y and int(nx)<img_x:
                        z1[img_y-1-int(ny),int(nx)]=tbl_ch2[ch2[i,j],1]
                        z2[img_y-1-int(ny),int(nx)]=tbl_ch4[ch4[i,j],1]

fig=plt.figure()

ax1 = fig.add_subplot(1,2,1)
cm1 = ax1.imshow(z1,cmap="gray",norm=Normalize(vmin=0,vmax=15))
ax1.set_title("Ch.2")
ax1.set_xlabel('Longitude direction')
ax1.set_ylabel('Latitude direction')
divider = make_axes_locatable(ax1)
cax = divider.append_axes("bottom",size="5%",pad=0.6)
cbar = fig.colorbar(cm1,cax=cax,orientation='horizontal')
cbar.set_label('Albedo (%)')

ax2 = fig.add_subplot(1,2,2)
cm2 = ax2.imshow(z2,cmap="jet",norm=Normalize(vmin=5.0,vmax=25.0))
ax2.set_title("Ch.4")
ax2.set_xlabel('Longitude direction')
ax2.set_ylabel('Latitude direction')
divider = make_axes_locatable(ax2)
cax = divider.append_axes("bottom",size="5%",pad=0.6)
cbar = fig.colorbar(cm2,cax=cax,orientation='horizontal')
cbar.set_label('Brightness Temp. (degC)')

plt.subplots_adjust(wspace=0.5)
plt.savefig('f03b.png')
plt.show()
